package com.example.android.lagosdevproject;

import static org.junit.Assert.*;

/**
 * Created by SEAMFIX PC on 28/08/2017.
 */
public class MainActivityTest {

}