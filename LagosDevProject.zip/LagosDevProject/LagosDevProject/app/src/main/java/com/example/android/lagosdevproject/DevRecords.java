package com.example.android.lagosdevproject;

/**
 * Created by SEAMFIX PC on 28/08/2017.
 */

public class DevRecords {
    private String login;
    private String avatar_url;
    private String html_url;

    public DevRecords(String avatar_url, String login, String html_url) {
        this.avatar_url = avatar_url;
        this.login = login;
        this.html_url = html_url;
    }

    public String getLogin() {
        return login;
    }

    public String getAvatarUrl() {
        return avatar_url;
    }

    public String getHtmlUrl() { return html_url; }
}

