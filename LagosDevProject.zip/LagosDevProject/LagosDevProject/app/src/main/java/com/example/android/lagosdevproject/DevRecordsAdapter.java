package com.example.android.lagosdevproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import com.android.volley.toolbox.ImageLoader;
import de.hdodenhof.circleimageview.CircleImageView;


import com.android.volley.toolbox.NetworkImageView;

import java.util.List;

/**
 * Created by SEAMFIX PC on 28/08/2017.
 */

public class DevRecordsAdapter  extends ArrayAdapter<DevRecords> {
    private ImageLoader mImageLoader;

    public DevRecordsAdapter(Context context) {
        super(context, R.layout.devs_view);

        mImageLoader = new ImageLoader(VolleyApplication.getInstance().getRequestQueue(), new BitmapLruCache());
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if(convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.devs_view, parent, false);
        }

        // Users Records that populates the list view
        NetworkImageView imageView = (NetworkImageView) convertView.findViewById(R.id.image1);
        TextView textView = (TextView) convertView.findViewById(R.id.text1);
        TextView textView1 = (TextView) convertView.findViewById(R.id.text2);
        TextView textView2 = (TextView) convertView.findViewById(R.id.text3);

        DevRecords imageRecord = getItem(position);

        imageView.setImageUrl(imageRecord.getAvatarUrl(), mImageLoader);
        textView.setText(imageRecord.getLogin());
        textView1.setText(imageRecord.getHtmlUrl());
        textView2.setText(imageRecord.getAvatarUrl());


        return convertView;
    }

    public void swapImageRecords(List<DevRecords> objects) {
        clear();

        for(DevRecords object : objects) {
            add(object);
        }

        notifyDataSetChanged();
    }
}